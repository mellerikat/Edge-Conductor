{{/*
Define registry name
*/}}
{{- define "edge-conductor.registry.name" -}}
{{- printf "%s-registry" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
    

{{/*
Common labels
*/}}
{{- define "edge-conductor.registry.labels" -}}
helm.sh/chart: {{ include "edge-conductor.chart" . }}
{{ include "edge-conductor.registry.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}


{{/*
Selector labels
*/}}
{{- define "edge-conductor.registry.selectorLabels" -}}
app.kubernetes.io/name: {{ include "edge-conductor.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: registry
{{- end }}


{{/*
Create the name of the internal service to use
*/}}    
{{- define "edge-conductor.registry.svc.internal.name" -}}
{{- printf "%s-registry-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}