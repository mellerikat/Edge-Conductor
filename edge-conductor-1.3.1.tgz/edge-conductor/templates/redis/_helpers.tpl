{{/*
Define redis name
*/}}
{{- define "edge-conductor.redis.name" -}}
{{- printf "%s-redis" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "edge-conductor.redis.labels" -}}
helm.sh/chart: {{ include "edge-conductor.chart" . }}
{{ include "edge-conductor.redis.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}


{{/*
Selector labels
*/}}
{{- define "edge-conductor.redis.selectorLabels" -}}
app.kubernetes.io/name: {{ include "edge-conductor.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: redis
{{- end }}


{{/*
Create the name of the internal service to use
*/}}    
{{- define "edge-conductor.redis.svc.internal.name" -}}
{{- printf "%s-redis-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}