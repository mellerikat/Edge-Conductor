# Edge Conductor



## Getting started
Please read the following content for managing the Edge Conductor.  

## Release notes

|     Date     | Version |      Note       |
|:------------:|:-------:|:---------------:|
| `2024.01.25` | `1.0.0` |      Init       |



## Requirments
This module requires the following information:
- access key 
- secret key 
- version

If you do not have a pair of keys, please contact AI Advisor administrator.

---

## Install

Install the Edge Conductor.

#### 1. Check which version to install
```bash
$ sudo ./edgecond.sh update --registry xxx --access_key xxx --secret_key xxx --list_upgradable

List of upgradable versions
2.0-alpha3.5.3
2.0-alpha3.5.4
```

#### 2. Install & Configure
```bash
$ sudo ./edgecond.sh configure --registry xxx --access_key xxx --secret_key xxx --version 2.0-alpha3.5.3

Config...
... 
...
### Input value or press enter.
# container
CONTAINER_NAME [prod-script] 

# db
MYSQL_HOST [192.0.1.4] 
MYSQL_PORT [39400] 
MYSQL_PSWD [passwd] 
...
...
Completed configure
Run command : ./edgecond.sh run
```

#### 3. Run
```bash
$ sudo ./edgecond.sh run

Run...
[+] Running 6/6
 ✔ Container aiadvisor-edge_conductor-mysql-995-prod-script           Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-backend-995-prod-script         Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-frontend-995-prod-script        Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-registry-995-prod-script        Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-otelcollector-995-prod-script   Started                             0.0s 
 ✔ Container aiadvisor-edge_conductor-registry_proxy-995-prod-script  Started                             0.0s
```

---

## Update
Check the list of new versions and update a new version.

#### 1. Stop
```bash
$ sudo ./edgecond.sh stop

stop...
[+] Running 7/7
 ✔ Container aiadvisor-edge_conductor-registry-995-prod-script        Removed                             0.4s 
 ✔ Container aiadvisor-edge_conductor-registry_proxy-995-prod-script  Removed                             0.0s 
 ✔ Container aiadvisor-edge_conductor-frontend-995-prod-script        Removed                             0.5s 
 ✔ Container aiadvisor-edge_conductor-otelcollector-995-prod-script   Removed                             0.0s 
 ✔ Container aiadvisor-edge_conductor-backend-995-prod-script         Removed                            10.5s 
 ✔ Container aiadvisor-edge_conductor-mysql-995-prod-script           Removed                             2.0s 
 ✔ Network edgecond_default                                           Removed                             0.3s 
```


#### 2. Update
```bash
$ sudo ./edgecond.sh update --registry xxx.amazonaws.com --access_key xxx --secret_key xxx 

List of upgradable versions
2.0-alpha3.5.3
2.0-alpha3.5.4

Current versions : 2.0-alpha3.5.3 

Please input one the list of upgradeable versions : 2.0-alpha3.5.4
...
...
### If the value of each item has changed, input value. 
### If there is no change, press the Enter key. 
# container
CONTAINER_NAME [prod-script] 

# db
MYSQL_HOST [192.0.1.4] 
MYSQL_PORT [39400] 
MYSQL_PSWD [passwd] 
...
...
Completed configure
Run command : ./edgecond.sh run
```

#### 3. Run
```bash
$ sudo ./edgecond.sh run

Run...
[+] Running 6/6
 ✔ Container aiadvisor-edge_conductor-mysql-995-prod-script           Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-backend-995-prod-script         Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-frontend-995-prod-script        Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-registry-995-prod-script        Running                             0.0s 
 ✔ Container aiadvisor-edge_conductor-otelcollector-995-prod-script   Started                             0.0s 
 ✔ Container aiadvisor-edge_conductor-registry_proxy-995-prod-script  Started                             0.0s
```

---

## Uninstall

Delete installed the Edge Conductor. 
> **_NOTE:_**  Please be careful that all data stored on the server will be deleted.


#### 1. Stop
```bash
$ sudo ./edgecond.sh stop

stop...
[+] Running 7/7
 ✔ Container aiadvisor-edge_conductor-registry-995-prod-script        Removed                             0.4s 
 ✔ Container aiadvisor-edge_conductor-registry_proxy-995-prod-script  Removed                             0.0s 
 ✔ Container aiadvisor-edge_conductor-frontend-995-prod-script        Removed                             0.5s 
 ✔ Container aiadvisor-edge_conductor-otelcollector-995-prod-script   Removed                             0.0s 
 ✔ Container aiadvisor-edge_conductor-backend-995-prod-script         Removed                            10.5s 
 ✔ Container aiadvisor-edge_conductor-mysql-995-prod-script           Removed                             2.0s 
 ✔ Network edgecond_default                                           Removed                             0.3s 
```

#### 2. Clear
```bash
$ sudo ./edgecond.sh clear
Clear...
All saved data will be deleted. Do you want to continue? (y/n) y
delete imamges... 
Deleted Images:
untagged: registry:2.8.2
...
Removing files ...
Removing user edgecond ...
Warning: group aiadvisor has no more members.
userdel: user edgecond is currently used by process 3005
```

---

## Other commands

#### Show current version
```bash
$ sudo ./edgecond.sh version

2.0-alpha3.5.4
```


#### Show current config
```bash
$ sudo ./edgecond.sh config

# container
CONTAINER_NAME=prod-script
HOSTUID=995
HOSTGID=996
# db
MYSQL_HOST=192.0.1.4
MYSQL_PORT=39400
...
...
BACKEND_CORS_ORIGINS='["http://192.0.1.4:39401", "http://localhost:39401", "http://127.0.0.1:39401"]'
```

---

## License
Copyright © 2024, [LG Electronics Inc.](https://lge.com/)
Released under the [LGE](LICENSE).

_This file was generated by [Intellytics Project](https://), 2.0, on 2024