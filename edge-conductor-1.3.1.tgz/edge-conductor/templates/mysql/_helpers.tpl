{{/*
Define redis name
*/}}
{{- define "edge-conductor.mysql.name" -}}
{{- printf "%s-mysql" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}


{{/*
Common labels
*/}}
{{- define "edge-conductor.mysql.labels" -}}
helm.sh/chart: {{ include "edge-conductor.chart" . }}
{{ include "edge-conductor.mysql.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "edge-conductor.mysql.selectorLabels" -}}
app.kubernetes.io/name: {{ include "edge-conductor.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: mysql
{{- end }}


{{/*
Create the name of the internal service to use
*/}}    
{{- define "edge-conductor.mysql.svc.internal.name" -}}
{{- printf "%s-mysql-internal" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}