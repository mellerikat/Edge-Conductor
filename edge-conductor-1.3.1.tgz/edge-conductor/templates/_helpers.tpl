{{/*
Expand the name of the chart.
*/}}
{{- define "edge-conductor.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "edge-conductor.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "edge-conductor.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "edge-conductor.labels" -}}
helm.sh/chart: {{ include "edge-conductor.chart" . }}
{{ include "edge-conductor.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "edge-conductor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "edge-conductor.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "edge-conductor.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "edge-conductor.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
Define secretProvider name
*/}}
{{- define "edge-conductor.secretProvider.name" -}}
{{- if and .Values.secret .Values.secret.secretProvider .Values.secret.secretProvider.nameOverride }}
{{- .Values.secret.secretProvider.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secretprovider" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Create the name of the configMap to use
*/}}    
{{- define "edge-conductor.configMap.name" -}}
{{- if and .Values.configMap .Values.configMap.nameOverride }}
{{- .Values.configMap.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "config-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define pv name
*/}}
{{- define "edge-conductor.pv.name" -}}
{{- if and .Values.pv .Values.pv.nameOverride }}
{{- .Values.pv.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pv-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define pvc name
*/}}
{{- define "edge-conductor.pvc.name" -}}
{{- if and .Values.pv .Values.pv.pvc .Values.pv.pvc.nameOverride }}
{{- .Values.pv.pvc.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pvc-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end}}